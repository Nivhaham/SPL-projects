package bgu.spl.mics.application.messages;

import bgu.spl.mics.Broadcast;
import bgu.spl.mics.Callback;
//import com.sun.xml.internal.bind.v2.

public class TerminationBroadCast  implements Broadcast {


}
