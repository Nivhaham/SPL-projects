package bgu.spl.mics.application.messages;
import bgu.spl.mics.Event;
//import com.sun.org.apache.xalan.internal.xsltc.compiler.util.BooleanType;

public class BombDestroyerEvent implements  Event<Boolean>{



}
