package bgu.spl.mics.application.passiveObjects;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

class EwokTest {
  /*  private Ewok test;

    @BeforeEach
    void setUp()
    {
        test = new Ewok();
    }

    @AfterEach
    void tearDown()
    {
    }

    @Test
    void acquire()
    {
        test.acquire();
        assertEquals(false,test.available);
    }

    @Test
    void release()
    {
        test.acquire();
        test.release();
        assertEquals(true,!(test.available));
    }*/
}