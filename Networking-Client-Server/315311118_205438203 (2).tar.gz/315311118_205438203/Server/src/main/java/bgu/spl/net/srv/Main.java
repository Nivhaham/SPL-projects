package bgu.spl.net.srv;

import java.util.Arrays;
import java.util.stream.Stream;

public class Main {


    public static void main(String[] args)
    {

        String [] x=("Niv"+"\0").split("\0");

      System.out.println(x.length);
    }
}
